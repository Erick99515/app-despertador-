package com.despertador.app;

import android.app.Activity;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.PowerManager;
import android.provider.Settings;
import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

@CapacitorPlugin(name = "AlarmNative")
public class AlarmPlugin extends Plugin {

    @PluginMethod
    public void agendar(PluginCall call) {
        try {
            JSArray itens = call.getArray("itens");
            AlarmUtil.agendarLista(getContext(), itens);
            call.resolve();
        } catch (Exception e) {
            call.reject(String.valueOf(e.getMessage()));
        }
    }

    @PluginMethod
    public void parar(PluginCall call) {
        getContext().stopService(new Intent(getContext(), AlarmService.class));
        limparTela();
        call.resolve();
    }

    @PluginMethod
    public void soneca(PluginCall call) {
        JSObject d = call.getData();
        AlarmUtil.definir(getContext(), AlarmUtil.SONECA_ID, d.optLong("ts"), d.optString("time", ""),
                d.optString("label", ""), d.optString("som", "classico"), "");
        getContext().stopService(new Intent(getContext(), AlarmService.class));
        limparTela();
        call.resolve();
    }

    @PluginMethod
    public void cancelarSoneca(PluginCall call) {
        AlarmUtil.cancelar(getContext(), AlarmUtil.SONECA_ID);
        call.resolve();
    }

    @PluginMethod
    public void tocando(PluginCall call) {
        JSObject r = new JSObject();
        r.put("ringing", AlarmService.tocando);
        r.put("time", AlarmService.time);
        r.put("label", AlarmService.label);
        r.put("som", AlarmService.som);
        r.put("aid", AlarmService.aid);
        call.resolve(r);
    }

    @PluginMethod
    public void permissoes(PluginCall call) {
        Context c = getContext();
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        boolean notif = true;
        if (Build.VERSION.SDK_INT >= 24) notif = nm.areNotificationsEnabled();
        boolean tela = true;
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                tela = (Boolean) NotificationManager.class.getMethod("canUseFullScreenIntent").invoke(nm);
            }
        } catch (Throwable t) {
            tela = true;
        }
        boolean bateria = true;
        try {
            PowerManager pm = (PowerManager) c.getSystemService(Context.POWER_SERVICE);
            if (Build.VERSION.SDK_INT >= 23) bateria = pm.isIgnoringBatteryOptimizations(c.getPackageName());
        } catch (Throwable t) {
            bateria = true;
        }
        JSObject r = new JSObject();
        r.put("notif", notif);
        r.put("tela", tela);
        r.put("bateria", bateria);
        call.resolve(r);
    }

    @PluginMethod
    public void abrir(PluginCall call) {
        String tipo = call.getString("tipo", "");
        Context c = getContext();
        String pkg = c.getPackageName();
        try {
            Intent i;
            if ("notif".equals(tipo)) {
                SharedPreferences sp = c.getSharedPreferences("alarmes", Context.MODE_PRIVATE);
                if (Build.VERSION.SDK_INT >= 33 && !sp.getBoolean("pediu", false)
                        && c.checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
                    sp.edit().putBoolean("pediu", true).apply();
                    getActivity().requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 1001);
                    call.resolve();
                    return;
                }
                i = new Intent("android.settings.APP_NOTIFICATION_SETTINGS");
                i.putExtra("android.provider.extra.APP_PACKAGE", pkg);
            } else if ("tela".equals(tipo)) {
                i = new Intent("android.settings.MANAGE_APP_USE_FULL_SCREEN_INTENT", Uri.parse("package:" + pkg));
            } else if ("bateria".equals(tipo)) {
                i = new Intent("android.settings.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS", Uri.parse("package:" + pkg));
            } else {
                i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + pkg));
            }
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            c.startActivity(i);
        } catch (Exception e) {
            try {
                Intent d = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + pkg));
                d.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                c.startActivity(d);
            } catch (Exception e2) {
            }
        }
        call.resolve();
    }

    private void limparTela() {
        final Activity a = getActivity();
        if (a == null || Build.VERSION.SDK_INT < 27) return;
        a.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                a.setShowWhenLocked(false);
                a.setTurnScreenOn(false);
            }
        });
    }
}
