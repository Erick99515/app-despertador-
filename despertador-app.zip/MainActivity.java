package com.despertador.app;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(AlarmPlugin.class);
        super.onCreate(savedInstanceState);
        aplicar(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        aplicar(intent);
    }

    private void aplicar(Intent in) {
        boolean alarme = in != null && in.getBooleanExtra("alarme", false);
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(alarme);
            setTurnScreenOn(alarme);
        }
    }
}
