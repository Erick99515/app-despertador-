import glob, math, os, shutil, struct, wave
SR = 22050

def nota(b, f, d, parts=((1, 1.0),), decay=0.0, vol=0.6):
    n = int(SR * d)
    tot = sum(a for _, a in parts)
    for i in range(n):
        t = i / SR
        env = min(1.0, t / 0.008, (d - t) / 0.02)
        if decay:
            env *= math.exp(-decay * t)
        v = sum(a * math.sin(2 * math.pi * f * m * t) for m, a in parts) / tot
        b.append(int(32767 * vol * env * v))

def pausa(b, d):
    b.extend([0] * int(SR * d))

def varrer(b, f0, f1, d, vol=0.5):
    n = int(SR * d)
    ph = 0.0
    for i in range(n):
        ph += 2 * math.pi * (f0 + (f1 - f0) * i / n) / SR
        env = min(1.0, i / (SR * 0.01), (n - i) / (SR * 0.02))
        b.append(int(32767 * vol * env * math.sin(ph)))

def classico():
    b = []
    for _ in range(4):
        nota(b, 988, .16); pausa(b, .08); nota(b, 988, .16); pausa(b, .08); nota(b, 1319, .3); pausa(b, .4)
    return b

def digital():
    b = []
    for _ in range(3):
        for _ in range(4):
            nota(b, 1760, .07, vol=.5); pausa(b, .07)
        pausa(b, .6)
    return b

def suave():
    b = []
    for _ in range(2):
        for f in (523, 659, 784, 1047):
            nota(b, f, .6, ((1, 1), (2, .3)), decay=3.5); pausa(b, .05)
        pausa(b, 1.2)
    return b

def sino():
    b = []
    for _ in range(3):
        nota(b, 660, 1.8, ((1, 1), (2.76, .5), (5.4, .25)), decay=2.2); pausa(b, .2)
    return b

def sirene():
    b = []
    for _ in range(4):
        varrer(b, 700, 1100, .6); varrer(b, 1100, 700, .6)
    return b

def salvar(nome, b):
    dados = struct.pack('<%dh' % len(b), *b)
    for caminho in ('www/sons/%s.wav' % nome, 'android/app/src/main/res/raw/alarme_%s.wav' % nome):
        os.makedirs(os.path.dirname(caminho), exist_ok=True)
        w = wave.open(caminho, 'wb')
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR)
        w.writeframes(dados)
        w.close()

for nome, fn in (('classico', classico), ('digital', digital), ('suave', suave), ('sino', sino), ('sirene', sirene)):
    salvar(nome, fn())

dest = 'android/app/src/main/java/com/despertador/app'
os.makedirs(dest, exist_ok=True)
for f in glob.glob('fonte/*.java'):
    shutil.copy(f, dest)

m = 'android/app/src/main/AndroidManifest.xml'
s = open(m, encoding='utf-8').read()
perms = ['USE_EXACT_ALARM', 'POST_NOTIFICATIONS', 'VIBRATE', 'RECEIVE_BOOT_COMPLETED', 'WAKE_LOCK',
         'FOREGROUND_SERVICE', 'FOREGROUND_SERVICE_MEDIA_PLAYBACK', 'USE_FULL_SCREEN_INTENT',
         'REQUEST_IGNORE_BATTERY_OPTIMIZATIONS']
txt = ''.join('<uses-permission android:name="android.permission.%s" />' % p for p in perms)
txt += '<uses-permission android:name="android.permission.SCHEDULE_EXACT_ALARM" android:maxSdkVersion="32" />'
comp = ('<service android:name=".AlarmService" android:exported="false" android:foregroundServiceType="mediaPlayback" />'
        '<receiver android:name=".AlarmReceiver" android:exported="false" />'
        '<receiver android:name=".BootReceiver" android:exported="true"><intent-filter>'
        '<action android:name="android.intent.action.BOOT_COMPLETED" />'
        '<action android:name="android.intent.action.MY_PACKAGE_REPLACED" /></intent-filter></receiver>')
assert '<application' in s and '</application>' in s
s = s.replace('<application', txt + '<application', 1).replace('</application>', comp + '</application>', 1)
open(m, 'w', encoding='utf-8').write(s)
print('preparado')
