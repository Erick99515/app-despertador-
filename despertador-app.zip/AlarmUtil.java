package com.despertador.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;

final class AlarmUtil {
    static final int SONECA_ID = 99999;
    private static final String PREFS = "alarmes";

    private static PendingIntent receptor(Context c, int id, String time, String label, String som, String aid) {
        Intent i = new Intent(c, AlarmReceiver.class);
        i.setAction("com.despertador.app.ALARME");
        i.putExtra("time", time);
        i.putExtra("label", label);
        i.putExtra("som", som);
        i.putExtra("aid", aid);
        return PendingIntent.getBroadcast(c, id, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    static void definir(Context c, int id, long ts, String time, String label, String som, String aid) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        Intent abrir = new Intent(c, MainActivity.class);
        PendingIntent mostrar = PendingIntent.getActivity(c, 0, abrir, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        am.setAlarmClock(new AlarmManager.AlarmClockInfo(ts, mostrar), receptor(c, id, time, label, som, aid));
    }

    static void cancelar(Context c, int id) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        am.cancel(receptor(c, id, "", "", "", ""));
    }

    static void agendarLista(Context c, JSONArray arr) throws Exception {
        SharedPreferences sp = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        int antigos = sp.getInt("n", 0);
        for (int i = 1; i <= antigos; i++) cancelar(c, i);
        long agora = System.currentTimeMillis();
        int n = 0;
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.getJSONObject(i);
            long ts = o.getLong("ts");
            if (ts <= agora) continue;
            n++;
            definir(c, n, ts, o.optString("time", ""), o.optString("label", ""), o.optString("som", "classico"), o.optString("aid", ""));
        }
        sp.edit().putString("itens", arr.toString()).putInt("n", n).apply();
    }

    static void reagendar(Context c) {
        try {
            String s = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("itens", "[]");
            agendarLista(c, new JSONArray(s));
        } catch (Exception e) {
        }
    }
}
