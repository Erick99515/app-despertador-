package com.despertador.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.content.res.AssetFileDescriptor;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.VibrationEffect;
import android.os.Vibrator;
import java.util.Calendar;
import java.util.Locale;

public class AlarmService extends Service {
    static volatile boolean tocando = false;
    static volatile String time = "";
    static volatile String label = "";
    static volatile String som = "classico";
    static volatile String aid = "";

    private static final String CANAL = "alarme_tocando";
    private static final int NOTIF = 4242;
    private MediaPlayer mp;
    private Vibrator vib;
    private PowerManager.WakeLock wl;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final Runnable limite = new Runnable() {
        @Override
        public void run() {
            stopSelf();
        }
    };

    private static String nz(String s) {
        return s == null ? "" : s;
    }

    @Override
    public IBinder onBind(Intent i) {
        return null;
    }

    @Override
    public int onStartCommand(Intent in, int flags, int startId) {
        String acao = in != null ? in.getAction() : null;
        if ("PARAR".equals(acao)) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if ("SONECA".equals(acao)) {
            long ts = System.currentTimeMillis() + 5 * 60000L;
            Calendar cal = Calendar.getInstance();
            cal.setTimeInMillis(ts);
            String hm = String.format(Locale.US, "%02d:%02d", cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE));
            AlarmUtil.definir(this, AlarmUtil.SONECA_ID, ts, hm, label, som, "");
            stopSelf();
            return START_NOT_STICKY;
        }
        if (in != null) {
            time = nz(in.getStringExtra("time"));
            label = nz(in.getStringExtra("label"));
            String s = nz(in.getStringExtra("som")).replaceAll("[^a-z0-9_]", "");
            som = s.isEmpty() ? "classico" : s;
            aid = nz(in.getStringExtra("aid"));
        }
        liberar();
        iniciarNotificacao();
        tocando = true;
        volume();
        tocarSom();
        vibrar();
        travar();
        h.removeCallbacks(limite);
        h.postDelayed(limite, 5 * 60 * 1000L);
        return START_NOT_STICKY;
    }

    private void iniciarNotificacao() {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CANAL, "Alarme tocando", NotificationManager.IMPORTANCE_HIGH);
            ch.setSound(null, null);
            ch.enableVibration(false);
            ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            nm.createNotificationChannel(ch);
        }
        Intent abrir = new Intent(this, MainActivity.class);
        abrir.putExtra("alarme", true);
        abrir.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        int fl = PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE;
        PendingIntent pi = PendingIntent.getActivity(this, 1, abrir, fl);
        PendingIntent parar = PendingIntent.getService(this, 2, new Intent(this, AlarmService.class).setAction("PARAR"), fl);
        PendingIntent soneca = PendingIntent.getService(this, 3, new Intent(this, AlarmService.class).setAction("SONECA"), fl);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CANAL) : new Notification.Builder(this);
        b.setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle(label.isEmpty() ? "Despertador" : label)
                .setContentText("Alarme das " + time)
                .setCategory(Notification.CATEGORY_ALARM)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setOngoing(true)
                .setContentIntent(pi)
                .setFullScreenIntent(pi, true)
                .addAction(0, "Soneca", soneca)
                .addAction(0, "Parar", parar);
        if (Build.VERSION.SDK_INT < 26) b.setPriority(Notification.PRIORITY_MAX);
        Notification n = b.build();
        if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIF, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        else startForeground(NOTIF, n);
    }

    private void volume() {
        try {
            AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
            int max = am.getStreamMaxVolume(AudioManager.STREAM_ALARM);
            if (am.getStreamVolume(AudioManager.STREAM_ALARM) == 0) am.setStreamVolume(AudioManager.STREAM_ALARM, max / 2, 0);
        } catch (Exception e) {
        }
    }

    private void tocarSom() {
        try {
            mp = new MediaPlayer();
            mp.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build());
            int id = getResources().getIdentifier("alarme_" + som, "raw", getPackageName());
            if (id != 0) {
                AssetFileDescriptor afd = getResources().openRawResourceFd(id);
                mp.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
                afd.close();
            } else {
                Uri u = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
                mp.setDataSource(this, u);
            }
            mp.setLooping(true);
            mp.prepare();
            mp.start();
        } catch (Exception e) {
        }
    }

    private void vibrar() {
        try {
            vib = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            long[] p = {0, 700, 500};
            if (Build.VERSION.SDK_INT >= 26) vib.vibrate(VibrationEffect.createWaveform(p, 0));
            else vib.vibrate(p, 0);
        } catch (Exception e) {
        }
    }

    private void travar() {
        try {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "despertador:alarme");
            wl.acquire(6 * 60 * 1000L);
        } catch (Exception e) {
        }
    }

    private void liberar() {
        try {
            if (mp != null) mp.stop();
        } catch (Exception e) {
        }
        try {
            if (mp != null) mp.release();
        } catch (Exception e) {
        }
        mp = null;
        try {
            if (vib != null) vib.cancel();
        } catch (Exception e) {
        }
        try {
            if (wl != null && wl.isHeld()) wl.release();
        } catch (Exception e) {
        }
        wl = null;
    }

    @Override
    public void onDestroy() {
        h.removeCallbacks(limite);
        liberar();
        tocando = false;
        if (Build.VERSION.SDK_INT >= 24) stopForeground(Service.STOP_FOREGROUND_REMOVE);
        else stopForeground(true);
        super.onDestroy();
    }
}
